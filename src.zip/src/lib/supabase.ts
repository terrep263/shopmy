import { createClient } from '@supabase/supabase-js'

/**
 * Supabase client for browser or server (Auth, Storage, Realtime).
 * Database access uses Prisma + DATABASE_URL.
 */
export function createSupabaseClient() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL
  const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
  if (!url || !anonKey) return null
  return createClient(url, anonKey)
}
