<?php
if (!defined('ABSPATH')) { exit; }

class SMN_Admin_Menu {

    public static function init() {
        add_action('admin_menu', array(__CLASS__, 'register_menu'));
        add_action('admin_enqueue_scripts', array(__CLASS__, 'enqueue_assets'));
    }

    public static function register_menu() {
        $cap = 'manage_platform';
        if (current_user_can('manage_options')) { $cap = 'manage_options'; }

        add_menu_page(
            'ShopMyNeighborhood',
            'ShopMyNeighborhood',
            $cap,
            'smn-dashboard',
            array('SMN_Admin_Dashboard', 'render'),
            'dashicons-store',
            26
        );

        add_submenu_page('smn-dashboard', 'Dashboard', 'Dashboard', $cap, 'smn-dashboard', array('SMN_Admin_Dashboard', 'render'));
        add_submenu_page('smn-dashboard', 'Businesses', 'Businesses', $cap, 'smn-businesses', array(__CLASS__, 'render_businesses'));
        add_submenu_page('smn-dashboard', 'Categories', 'Categories', $cap, 'smn-categories', array(__CLASS__, 'render_categories'));
        add_submenu_page('smn-dashboard', 'Cities', 'Cities', $cap, 'smn-cities', array(__CLASS__, 'render_cities'));
        add_submenu_page('smn-dashboard', 'Counties', 'Counties', $cap, 'smn-counties', array(__CLASS__, 'render_counties'));
        add_submenu_page('smn-dashboard', 'Settings', 'Settings', $cap, 'smn-settings', array(__CLASS__, 'render_settings'));
    }

    public static function enqueue_assets($hook) {
        if (strpos($hook, 'smn-') === false && $hook !== 'toplevel_page_smn-dashboard') { return; }
        wp_enqueue_style('smn-admin', SMN_CORE_URL . 'assets/css/admin.css', array(), SMN_CORE_VERSION);
        wp_enqueue_script('smn-admin', SMN_CORE_URL . 'assets/js/admin.js', array('jquery'), SMN_CORE_VERSION, true);
    }

    private static function require_cap_or_die() {
        if (!current_user_can('manage_platform') && !current_user_can('manage_options')) {
            wp_die(__('You do not have permission to access this page.', 'shopmyneighborhood-core'));
        }
    }

    public static function render_businesses() {
        self::require_cap_or_die();
        require_once SMN_CORE_PATH . 'includes/class-smn-business.php';

        $items = SMN_Business::get_businesses(array('limit' => 50, 'offset' => 0));

        echo '<div class="wrap"><h1>Businesses</h1>';
        echo '<p>Core business records stored by ShopMyNeighborhood Core.</p>';
        echo '<table class="widefat striped"><thead><tr><th>ID</th><th>Name</th><th>County</th><th>City</th><th>Status</th><th>Claimed</th><th>Updated</th></tr></thead><tbody>';
        foreach ($items as $b) {
            echo '<tr>';
            echo '<td>' . esc_html($b['id']) . '</td>';
            echo '<td>' . esc_html($b['name']) . '</td>';
            echo '<td>' . esc_html($b['county']) . '</td>';
            echo '<td>' . esc_html($b['city']) . '</td>';
            echo '<td>' . esc_html($b['status']) . '</td>';
            echo '<td>' . (intval($b['is_claimed']) ? 'Yes' : 'No') . '</td>';
            echo '<td>' . esc_html($b['updated_at']) . '</td>';
            echo '</tr>';
        }
        if (empty($items)) {
            echo '<tr><td colspan="7">No businesses found yet.</td></tr>';
        }
        echo '</tbody></table></div>';
    }

    public static function render_categories() {
        self::require_cap_or_die();
        require_once SMN_CORE_PATH . 'includes/class-smn-location.php';

        if (isset($_POST['smn_add_category']) && check_admin_referer('smn_add_category_action', 'smn_nonce')) {
            $res = SMN_Location::create_category(array(
                'name' => $_POST['name'] ?? '',
                'slug' => $_POST['slug'] ?? '',
                'icon' => $_POST['icon'] ?? '',
            ));
            if (is_wp_error($res)) {
                echo '<div class="notice notice-error"><p>' . esc_html($res->get_error_message()) . '</p></div>';
            } else {
                echo '<div class="notice notice-success"><p>Category added.</p></div>';
            }
        }

        $items = SMN_Location::get_categories();

        echo '<div class="wrap"><h1>Categories</h1>';
        echo '<form method="post" style="margin:16px 0;">';
        wp_nonce_field('smn_add_category_action', 'smn_nonce');
        echo '<input type="hidden" name="smn_add_category" value="1" />';
        echo '<table class="form-table"><tr><th><label>Name</label></th><td><input name="name" class="regular-text" required></td></tr>';
        echo '<tr><th><label>Slug</label></th><td><input name="slug" class="regular-text" placeholder="optional"></td></tr>';
        echo '<tr><th><label>Icon</label></th><td><input name="icon" class="regular-text" placeholder="optional"></td></tr></table>';
        submit_button('Add Category');
        echo '</form>';

        echo '<table class="widefat striped"><thead><tr><th>ID</th><th>Name</th><th>Slug</th><th>Icon</th></tr></thead><tbody>';
        foreach ($items as $c) {
            echo '<tr><td>' . esc_html($c['id']) . '</td><td>' . esc_html($c['name']) . '</td><td>' . esc_html($c['slug']) . '</td><td>' . esc_html($c['icon']) . '</td></tr>';
        }
        if (empty($items)) {
            echo '<tr><td colspan="4">No categories found yet.</td></tr>';
        }
        echo '</tbody></table></div>';
    }

    public static function render_cities() {
        self::require_cap_or_die();
        require_once SMN_CORE_PATH . 'includes/class-smn-location.php';

        if (isset($_POST['smn_add_city']) && check_admin_referer('smn_add_city_action', 'smn_nonce')) {
            $res = SMN_Location::create_city(array(
                'name' => $_POST['name'] ?? '',
                'county' => $_POST['county'] ?? '',
                'state' => $_POST['state'] ?? '',
            ));
            if (is_wp_error($res)) {
                echo '<div class="notice notice-error"><p>' . esc_html($res->get_error_message()) . '</p></div>';
            } else {
                echo '<div class="notice notice-success"><p>City added.</p></div>';
            }
        }

        $items = SMN_Location::get_cities();

        echo '<div class="wrap"><h1>Cities</h1>';
        echo '<form method="post" style="margin:16px 0;">';
        wp_nonce_field('smn_add_city_action', 'smn_nonce');
        echo '<input type="hidden" name="smn_add_city" value="1" />';
        echo '<table class="form-table"><tr><th><label>Name</label></th><td><input name="name" class="regular-text" required></td></tr>';
        echo '<tr><th><label>County</label></th><td><input name="county" class="regular-text" placeholder="e.g., Lake"></td></tr>';
        echo '<tr><th><label>State</label></th><td><input name="state" class="regular-text" placeholder="e.g., FL"></td></tr></table>';
        submit_button('Add City');
        echo '</form>';

        echo '<table class="widefat striped"><thead><tr><th>ID</th><th>Name</th><th>County</th><th>State</th></tr></thead><tbody>';
        foreach ($items as $c) {
            echo '<tr><td>' . esc_html($c['id']) . '</td><td>' . esc_html($c['name']) . '</td><td>' . esc_html($c['county']) . '</td><td>' . esc_html($c['state']) . '</td></tr>';
        }
        if (empty($items)) {
            echo '<tr><td colspan="4">No cities found yet.</td></tr>';
        }
        echo '</tbody></table></div>';
    }

    public static function render_counties() {
        self::require_cap_or_die();
        require_once SMN_CORE_PATH . 'includes/class-smn-location.php';

        if (isset($_POST['smn_add_county']) && check_admin_referer('smn_add_county_action', 'smn_nonce')) {
            $res = SMN_Location::create_county(array(
                'name' => $_POST['name'] ?? '',
                'state' => $_POST['state'] ?? '',
            ));
            if (is_wp_error($res)) {
                echo '<div class="notice notice-error"><p>' . esc_html($res->get_error_message()) . '</p></div>';
            } else {
                echo '<div class="notice notice-success"><p>County added.</p></div>';
            }
        }

        $items = SMN_Location::get_counties();

        echo '<div class="wrap"><h1>Counties</h1>';
        echo '<form method="post" style="margin:16px 0;">';
        wp_nonce_field('smn_add_county_action', 'smn_nonce');
        echo '<input type="hidden" name="smn_add_county" value="1" />';
        echo '<table class="form-table"><tr><th><label>Name</label></th><td><input name="name" class="regular-text" required></td></tr>';
        echo '<tr><th><label>State</label></th><td><input name="state" class="regular-text" placeholder="e.g., FL"></td></tr></table>';
        submit_button('Add County');
        echo '</form>';

        echo '<table class="widefat striped"><thead><tr><th>ID</th><th>Name</th><th>State</th></tr></thead><tbody>';
        foreach ($items as $c) {
            echo '<tr><td>' . esc_html($c['id']) . '</td><td>' . esc_html($c['name']) . '</td><td>' . esc_html($c['state']) . '</td></tr>';
        }
        if (empty($items)) {
            echo '<tr><td colspan="3">No counties found yet.</td></tr>';
        }
        echo '</tbody></table></div>';
    }

    public static function render_settings() {
        self::require_cap_or_die();
        echo '<div class="wrap"><h1>Settings</h1>';
        echo '<p>Core settings storage is available in the smn_platform_settings table. Platform modules will provide UI for specific settings.</p>';
        echo '</div>';
    }
}
