<?php
if (!defined('ABSPATH')) { exit; }

class SMN_Admin_Dashboard {

    public static function render() {
        if (!current_user_can('manage_platform') && !current_user_can('manage_options')) {
            wp_die(__('You do not have permission to access this page.', 'shopmyneighborhood-core'));
        }

        global $wpdb;
        $t_businesses = $wpdb->prefix . 'smn_businesses';
        $t_vb = $wpdb->prefix . 'smn_vendor_businesses';
        $t_categories = $wpdb->prefix . 'smn_categories';
        $t_cities = $wpdb->prefix . 'smn_cities';

        $business_count = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$t_businesses}");
        $vendor_links = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$t_vb}");
        $category_count = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$t_categories}");
        $city_count = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$t_cities}");

        echo '<div class="wrap"><h1>ShopMyNeighborhood Dashboard</h1>';
        echo '<div class="smn-cards">';
        echo '<div class="smn-card"><h2>Total Businesses</h2><p class="smn-metric">' . esc_html($business_count) . '</p></div>';
        echo '<div class="smn-card"><h2>Total Vendor Links</h2><p class="smn-metric">' . esc_html($vendor_links) . '</p></div>';
        echo '<div class="smn-card"><h2>Total Categories</h2><p class="smn-metric">' . esc_html($category_count) . '</p></div>';
        echo '<div class="smn-card"><h2>Total Cities</h2><p class="smn-metric">' . esc_html($city_count) . '</p></div>';
        echo '</div>';
        echo '<p>This is the core foundation plugin. Platform modules (imports, claims, deals, vouchers, subscriptions, AI) will plug into this base.</p>';
        echo '</div>';
    }
}
