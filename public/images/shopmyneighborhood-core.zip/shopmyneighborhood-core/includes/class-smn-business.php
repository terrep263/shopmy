<?php
if (!defined('ABSPATH')) { exit; }

class SMN_Business {

    private static function table() {
        global $wpdb;
        return $wpdb->prefix . 'smn_businesses';
    }

    private static function now() {
        return current_time('mysql');
    }

    public static function create_business($data) {
        global $wpdb;
        $table = self::table();

        $name = isset($data['name']) ? sanitize_text_field($data['name']) : '';
        if ($name === '') { return new WP_Error('smn_invalid_name', 'Business name is required.'); }

        $place_id = isset($data['place_id']) ? sanitize_text_field($data['place_id']) : null;
        $slug = isset($data['slug']) && $data['slug'] !== '' ? sanitize_title($data['slug']) : sanitize_title($name);
        $description = isset($data['description']) ? wp_kses_post($data['description']) : null;
        $address = isset($data['address']) ? sanitize_textarea_field($data['address']) : null;

        $row = array(
            'place_id' => $place_id,
            'name' => $name,
            'slug' => $slug,
            'description' => $description,
            'address' => $address,
            'city' => isset($data['city']) ? sanitize_text_field($data['city']) : null,
            'county' => isset($data['county']) ? sanitize_text_field($data['county']) : null,
            'state' => isset($data['state']) ? sanitize_text_field($data['state']) : null,
            'postal_code' => isset($data['postal_code']) ? sanitize_text_field($data['postal_code']) : null,
            'country' => isset($data['country']) ? sanitize_text_field($data['country']) : null,
            'phone' => isset($data['phone']) ? sanitize_text_field($data['phone']) : null,
            'website' => isset($data['website']) ? esc_url_raw($data['website']) : null,
            'latitude' => isset($data['latitude']) ? floatval($data['latitude']) : null,
            'longitude' => isset($data['longitude']) ? floatval($data['longitude']) : null,
            'category_id' => isset($data['category_id']) ? absint($data['category_id']) : null,
            'is_claimed' => isset($data['is_claimed']) ? (int)!!$data['is_claimed'] : 0,
            'status' => isset($data['status']) ? sanitize_text_field($data['status']) : 'active',
            'created_at' => self::now(),
            'updated_at' => self::now(),
        );

        $formats = array('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%f','%f','%d','%d','%s','%s','%s');

        $result = $wpdb->insert($table, $row, $formats);
        if ($result === false) {
            return new WP_Error('smn_db_insert_failed', 'Failed to create business.', array('db_error' => $wpdb->last_error));
        }
        return (int) $wpdb->insert_id;
    }

    public static function update_business($business_id, $data) {
        global $wpdb;
        $table = self::table();
        $business_id = absint($business_id);
        if ($business_id <= 0) { return new WP_Error('smn_invalid_id', 'Invalid business id.'); }

        $row = array();
        $formats = array();

        $map = array(
            'place_id' => 'sanitize_text_field',
            'name' => 'sanitize_text_field',
            'slug' => 'sanitize_title',
            'description' => 'wp_kses_post',
            'address' => 'sanitize_textarea_field',
            'city' => 'sanitize_text_field',
            'county' => 'sanitize_text_field',
            'state' => 'sanitize_text_field',
            'postal_code' => 'sanitize_text_field',
            'country' => 'sanitize_text_field',
            'phone' => 'sanitize_text_field',
            'website' => 'esc_url_raw',
            'status' => 'sanitize_text_field',
        );

        foreach ($map as $key => $fn) {
            if (array_key_exists($key, $data)) {
                $row[$key] = call_user_func($fn, $data[$key]);
                $formats[] = '%s';
            }
        }

        if (array_key_exists('latitude', $data)) { $row['latitude'] = floatval($data['latitude']); $formats[] = '%f'; }
        if (array_key_exists('longitude', $data)) { $row['longitude'] = floatval($data['longitude']); $formats[] = '%f'; }
        if (array_key_exists('category_id', $data)) { $row['category_id'] = absint($data['category_id']); $formats[] = '%d'; }
        if (array_key_exists('is_claimed', $data)) { $row['is_claimed'] = (int)!!$data['is_claimed']; $formats[] = '%d'; }

        $row['updated_at'] = self::now();
        $formats[] = '%s';

        if (empty($row)) { return true; }

        $result = $wpdb->update($table, $row, array('id' => $business_id), $formats, array('%d'));
        if ($result === false) {
            return new WP_Error('smn_db_update_failed', 'Failed to update business.', array('db_error' => $wpdb->last_error));
        }
        return true;
    }

    public static function get_business($business_id) {
        global $wpdb;
        $table = self::table();
        $business_id = absint($business_id);
        if ($business_id <= 0) { return null; }
        $sql = $wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $business_id);
        return $wpdb->get_row($sql, ARRAY_A);
    }

    public static function get_business_by_place_id($place_id) {
        global $wpdb;
        $table = self::table();
        $place_id = sanitize_text_field($place_id);
        if ($place_id === '') { return null; }
        $sql = $wpdb->prepare("SELECT * FROM {$table} WHERE place_id = %s", $place_id);
        return $wpdb->get_row($sql, ARRAY_A);
    }

    public static function get_business_by_slug($slug) {
        global $wpdb;
        $table = self::table();
        $slug = sanitize_title($slug);
        if ($slug === '') { return null; }
        $sql = $wpdb->prepare("SELECT * FROM {$table} WHERE slug = %s", $slug);
        return $wpdb->get_row($sql, ARRAY_A);
    }

    public static function get_businesses($filters = array()) {
        global $wpdb;
        $table = self::table();

        $where = array("1=1");
        $args = array();

        if (!empty($filters['county'])) { $where[] = "county = %s"; $args[] = sanitize_text_field($filters['county']); }
        if (!empty($filters['city'])) { $where[] = "city = %s"; $args[] = sanitize_text_field($filters['city']); }
        if (!empty($filters['status'])) { $where[] = "status = %s"; $args[] = sanitize_text_field($filters['status']); }
        if (!empty($filters['category_id'])) { $where[] = "category_id = %d"; $args[] = absint($filters['category_id']); }
        if (isset($filters['is_claimed'])) { $where[] = "is_claimed = %d"; $args[] = (int)!!$filters['is_claimed']; }

        $limit = isset($filters['limit']) ? min(500, max(1, absint($filters['limit']))) : 50;
        $offset = isset($filters['offset']) ? max(0, absint($filters['offset'])) : 0;

        $sql = "SELECT * FROM {$table} WHERE " . implode(' AND ', $where) . " ORDER BY updated_at DESC LIMIT %d OFFSET %d";
        $args[] = $limit;
        $args[] = $offset;

        $prepared = $wpdb->prepare($sql, $args);
        return $wpdb->get_results($prepared, ARRAY_A);
    }

    public static function delete_business($business_id) {
        global $wpdb;
        $table = self::table();
        $business_id = absint($business_id);
        if ($business_id <= 0) { return new WP_Error('smn_invalid_id', 'Invalid business id.'); }
        $result = $wpdb->delete($table, array('id' => $business_id), array('%d'));
        if ($result === false) {
            return new WP_Error('smn_db_delete_failed', 'Failed to delete business.', array('db_error' => $wpdb->last_error));
        }
        return true;
    }
}
