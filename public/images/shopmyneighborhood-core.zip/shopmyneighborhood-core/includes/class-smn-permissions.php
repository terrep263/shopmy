<?php
if (!defined('ABSPATH')) { exit; }

class SMN_Permissions {

    public static function current_user_is_platform_admin() {
        return current_user_can('manage_platform') || current_user_can('manage_options');
    }

    public static function current_user_is_county_admin() {
        return current_user_can('manage_county_businesses');
    }

    public static function current_user_is_vendor() {
        return current_user_can('manage_own_business');
    }

    public static function current_user_owns_business($business_id) {
        $business_id = absint($business_id);
        if ($business_id <= 0) { return false; }

        $user_id = get_current_user_id();
        if ($user_id <= 0) { return false; }

        require_once SMN_CORE_PATH . 'includes/class-smn-vendor.php';
        return SMN_Vendor::vendor_owns_business($user_id, $business_id);
    }
}
