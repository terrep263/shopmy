<?php
if (!defined('ABSPATH')) { exit; }

class SMN_Core {

    private static $instance = null;

    public static function instance() {
        if (self::$instance === null) {
            self::$instance = new self();
            self::$instance->init();
        }
        return self::$instance;
    }

    private function __construct() {}

    private function init() {
        // Load core classes
        require_once SMN_CORE_PATH . 'includes/class-smn-roles.php';
        require_once SMN_CORE_PATH . 'includes/class-smn-database.php';
        require_once SMN_CORE_PATH . 'includes/class-smn-permissions.php';
        require_once SMN_CORE_PATH . 'includes/class-smn-business.php';
        require_once SMN_CORE_PATH . 'includes/class-smn-vendor.php';
        require_once SMN_CORE_PATH . 'includes/class-smn-location.php';
        require_once SMN_CORE_PATH . 'includes/class-smn-api.php';
        require_once SMN_CORE_PATH . 'admin/class-smn-admin-dashboard.php';
        require_once SMN_CORE_PATH . 'admin/class-smn-admin-menu.php';

        // Admin
        if (is_admin()) {
            SMN_Admin_Menu::init();
        }

        // REST API
        SMN_Api::init();

        // Public helper functions for Elementor/widgets
        $this->register_public_helpers();
    }

    private function register_public_helpers() {
        if (!function_exists('smn_get_business')) {
            function smn_get_business($id) {
                return SMN_Business::get_business($id);
            }
        }
        if (!function_exists('smn_get_businesses')) {
            function smn_get_businesses($filters = array()) {
                return SMN_Business::get_businesses($filters);
            }
        }
        if (!function_exists('smn_get_categories')) {
            function smn_get_categories() {
                return SMN_Location::get_categories();
            }
        }
    }
}
