<?php
if (!defined('ABSPATH')) { exit; }

class SMN_Vendor {

    private static function table() {
        global $wpdb;
        return $wpdb->prefix . 'smn_vendor_businesses';
    }

    private static function now() {
        return current_time('mysql');
    }

    public static function assign_vendor_to_business($vendor_user_id, $business_id, $ownership_status = 'approved') {
        global $wpdb;
        $table = self::table();

        $vendor_user_id = absint($vendor_user_id);
        $business_id = absint($business_id);
        $ownership_status = sanitize_text_field($ownership_status);

        if ($vendor_user_id <= 0 || $business_id <= 0) {
            return new WP_Error('smn_invalid_assignment', 'Invalid vendor or business id.');
        }

        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$table} WHERE vendor_user_id = %d AND business_id = %d",
            $vendor_user_id, $business_id
        ));

        if ($existing) {
            $updated = $wpdb->update(
                $table,
                array('ownership_status' => $ownership_status, 'updated_at' => self::now()),
                array('id' => absint($existing)),
                array('%s','%s'),
                array('%d')
            );
            if ($updated === false) {
                return new WP_Error('smn_db_update_failed', 'Failed to update vendor assignment.', array('db_error' => $wpdb->last_error));
            }
            return (int) $existing;
        }

        $inserted = $wpdb->insert(
            $table,
            array(
                'vendor_user_id' => $vendor_user_id,
                'business_id' => $business_id,
                'ownership_status' => $ownership_status,
                'created_at' => self::now(),
                'updated_at' => self::now(),
            ),
            array('%d','%d','%s','%s','%s')
        );

        if ($inserted === false) {
            return new WP_Error('smn_db_insert_failed', 'Failed to assign vendor to business.', array('db_error' => $wpdb->last_error));
        }
        return (int) $wpdb->insert_id;
    }

    public static function get_vendor_businesses($vendor_user_id) {
        global $wpdb;
        $table = self::table();
        $vendor_user_id = absint($vendor_user_id);
        if ($vendor_user_id <= 0) { return array(); }

        $sql = $wpdb->prepare(
            "SELECT * FROM {$table} WHERE vendor_user_id = %d ORDER BY updated_at DESC",
            $vendor_user_id
        );
        return $wpdb->get_results($sql, ARRAY_A);
    }

    public static function get_business_vendor($business_id) {
        global $wpdb;
        $table = self::table();
        $business_id = absint($business_id);
        if ($business_id <= 0) { return null; }

        $sql = $wpdb->prepare(
            "SELECT * FROM {$table} WHERE business_id = %d ORDER BY updated_at DESC LIMIT 1",
            $business_id
        );
        return $wpdb->get_row($sql, ARRAY_A);
    }

    public static function vendor_owns_business($vendor_user_id, $business_id) {
        global $wpdb;
        $table = self::table();
        $vendor_user_id = absint($vendor_user_id);
        $business_id = absint($business_id);
        if ($vendor_user_id <= 0 || $business_id <= 0) { return false; }

        $status = $wpdb->get_var($wpdb->prepare(
            "SELECT ownership_status FROM {$table} WHERE vendor_user_id = %d AND business_id = %d",
            $vendor_user_id, $business_id
        ));

        return ($status === 'approved');
    }
}
