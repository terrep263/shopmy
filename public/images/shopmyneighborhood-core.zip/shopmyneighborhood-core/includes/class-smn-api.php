<?php
if (!defined('ABSPATH')) { exit; }

class SMN_Api {

    public static function init() {
        add_action('rest_api_init', array(__CLASS__, 'register_routes'));
    }

    public static function register_routes() {
        register_rest_route('smn/v1', '/businesses', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array(__CLASS__, 'get_businesses'),
            'permission_callback' => '__return_true',
            'args' => array(
                'county' => array('type' => 'string'),
                'city' => array('type' => 'string'),
                'status' => array('type' => 'string'),
                'category_id' => array('type' => 'integer'),
                'is_claimed' => array('type' => 'boolean'),
                'limit' => array('type' => 'integer', 'default' => 50),
                'offset' => array('type' => 'integer', 'default' => 0),
            ),
        ));

        register_rest_route('smn/v1', '/business/(?P<id>\d+)', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array(__CLASS__, 'get_business'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route('smn/v1', '/categories', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array(__CLASS__, 'get_categories'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route('smn/v1', '/cities', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array(__CLASS__, 'get_cities'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route('smn/v1', '/counties', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array(__CLASS__, 'get_counties'),
            'permission_callback' => '__return_true',
        ));
    }

    public static function get_businesses(WP_REST_Request $request) {
        require_once SMN_CORE_PATH . 'includes/class-smn-business.php';

        $filters = array();
        foreach (array('county','city','status') as $k) {
            $v = $request->get_param($k);
            if (!empty($v)) { $filters[$k] = $v; }
        }
        foreach (array('category_id','limit','offset') as $k) {
            $v = $request->get_param($k);
            if ($v !== null && $v !== '') { $filters[$k] = $v; }
        }
        $is_claimed = $request->get_param('is_claimed');
        if ($is_claimed !== null) { $filters['is_claimed'] = (bool)$is_claimed; }

        $items = SMN_Business::get_businesses($filters);
        return rest_ensure_response(array('data' => $items));
    }

    public static function get_business(WP_REST_Request $request) {
        require_once SMN_CORE_PATH . 'includes/class-smn-business.php';
        $id = absint($request['id']);
        $item = SMN_Business::get_business($id);
        if (!$item) {
            return new WP_Error('smn_not_found', 'Business not found.', array('status' => 404));
        }
        return rest_ensure_response(array('data' => $item));
    }

    public static function get_categories() {
        require_once SMN_CORE_PATH . 'includes/class-smn-location.php';
        return rest_ensure_response(array('data' => SMN_Location::get_categories()));
    }

    public static function get_cities(WP_REST_Request $request) {
        require_once SMN_CORE_PATH . 'includes/class-smn-location.php';
        $filters = array();
        $county = $request->get_param('county');
        $state = $request->get_param('state');
        if (!empty($county)) { $filters['county'] = $county; }
        if (!empty($state)) { $filters['state'] = $state; }
        return rest_ensure_response(array('data' => SMN_Location::get_cities($filters)));
    }

    public static function get_counties(WP_REST_Request $request) {
        require_once SMN_CORE_PATH . 'includes/class-smn-location.php';
        $filters = array();
        $state = $request->get_param('state');
        if (!empty($state)) { $filters['state'] = $state; }
        return rest_ensure_response(array('data' => SMN_Location::get_counties($filters)));
    }
}
