<?php
if (!defined('ABSPATH')) { exit; }

class SMN_Activator {

    public static function activate() {
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        // Create tables
        require_once SMN_CORE_PATH . 'includes/class-smn-database.php';
        SMN_Database::install();

        // Roles
        require_once SMN_CORE_PATH . 'includes/class-smn-roles.php';
        SMN_Roles::add_roles();

        // Store DB version
        update_option('smn_core_db_version', SMN_CORE_DB_VERSION);
    }
}
