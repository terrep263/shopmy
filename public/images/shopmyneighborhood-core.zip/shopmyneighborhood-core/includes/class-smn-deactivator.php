<?php
if (!defined('ABSPATH')) { exit; }

class SMN_Deactivator {

    public static function deactivate() {
        // Remove custom roles only; do not delete tables or data.
        require_once SMN_CORE_PATH . 'includes/class-smn-roles.php';
        SMN_Roles::remove_roles();
    }
}
