<?php
if (!defined('ABSPATH')) { exit; }

class SMN_Database {

    public static function install() {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();

        $table_businesses = $wpdb->prefix . 'smn_businesses';
        $table_vendor_businesses = $wpdb->prefix . 'smn_vendor_businesses';
        $table_categories = $wpdb->prefix . 'smn_categories';
        $table_cities = $wpdb->prefix . 'smn_cities';
        $table_counties = $wpdb->prefix . 'smn_counties';
        $table_settings = $wpdb->prefix . 'smn_platform_settings';

        // Businesses
        $sql1 = "CREATE TABLE {$table_businesses} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            place_id VARCHAR(255) NULL,
            name VARCHAR(255) NOT NULL,
            slug VARCHAR(255) NOT NULL,
            description TEXT NULL,
            address TEXT NULL,
            city VARCHAR(150) NULL,
            county VARCHAR(150) NULL,
            state VARCHAR(100) NULL,
            postal_code VARCHAR(50) NULL,
            country VARCHAR(50) NULL,
            phone VARCHAR(50) NULL,
            website VARCHAR(255) NULL,
            latitude DECIMAL(10,8) NULL,
            longitude DECIMAL(11,8) NULL,
            category_id BIGINT UNSIGNED NULL,
            is_claimed TINYINT(1) NOT NULL DEFAULT 0,
            status VARCHAR(50) NOT NULL DEFAULT 'active',
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY place_id (place_id),
            KEY slug (slug),
            KEY category_id (category_id),
            KEY county (county),
            KEY city (city)
        ) {$charset_collate};";

        // Vendor Businesses
        $sql2 = "CREATE TABLE {$table_vendor_businesses} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            vendor_user_id BIGINT UNSIGNED NOT NULL,
            business_id BIGINT UNSIGNED NOT NULL,
            ownership_status VARCHAR(50) NOT NULL DEFAULT 'pending',
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY vendor_business_unique (vendor_user_id, business_id),
            KEY vendor_user_id (vendor_user_id),
            KEY business_id (business_id)
        ) {$charset_collate};";

        // Categories
        $sql3 = "CREATE TABLE {$table_categories} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            name VARCHAR(255) NOT NULL,
            slug VARCHAR(255) NOT NULL,
            icon VARCHAR(255) NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY slug (slug),
            KEY name (name)
        ) {$charset_collate};";

        // Cities
        $sql4 = "CREATE TABLE {$table_cities} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            name VARCHAR(255) NOT NULL,
            county VARCHAR(255) NULL,
            state VARCHAR(255) NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY name (name),
            KEY county (county)
        ) {$charset_collate};";

        // Counties
        $sql5 = "CREATE TABLE {$table_counties} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            name VARCHAR(255) NOT NULL,
            state VARCHAR(255) NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY name_state (name, state),
            KEY name (name)
        ) {$charset_collate};";

        // Settings
        $sql6 = "CREATE TABLE {$table_settings} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            setting_key VARCHAR(255) NOT NULL,
            setting_value LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY setting_key (setting_key)
        ) {$charset_collate};";

        dbDelta($sql1);
        dbDelta($sql2);
        dbDelta($sql3);
        dbDelta($sql4);
        dbDelta($sql5);
        dbDelta($sql6);
    }
}
