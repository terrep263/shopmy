<?php
if (!defined('ABSPATH')) { exit; }

class SMN_Location {

    private static function table_categories() {
        global $wpdb;
        return $wpdb->prefix . 'smn_categories';
    }
    private static function table_cities() {
        global $wpdb;
        return $wpdb->prefix . 'smn_cities';
    }
    private static function table_counties() {
        global $wpdb;
        return $wpdb->prefix . 'smn_counties';
    }
    private static function now() {
        return current_time('mysql');
    }

    public static function create_category($data) {
        global $wpdb;
        $table = self::table_categories();

        $name = isset($data['name']) ? sanitize_text_field($data['name']) : '';
        if ($name === '') { return new WP_Error('smn_invalid_category', 'Category name is required.'); }
        $slug = isset($data['slug']) && $data['slug'] !== '' ? sanitize_title($data['slug']) : sanitize_title($name);
        $icon = isset($data['icon']) ? sanitize_text_field($data['icon']) : null;

        $ok = $wpdb->insert($table, array(
            'name' => $name,
            'slug' => $slug,
            'icon' => $icon,
            'created_at' => self::now(),
        ), array('%s','%s','%s','%s'));

        if ($ok === false) {
            return new WP_Error('smn_db_insert_failed', 'Failed to create category.', array('db_error' => $wpdb->last_error));
        }
        return (int) $wpdb->insert_id;
    }

    public static function get_categories() {
        global $wpdb;
        $table = self::table_categories();
        return $wpdb->get_results("SELECT * FROM {$table} ORDER BY name ASC", ARRAY_A);
    }

    public static function create_city($data) {
        global $wpdb;
        $table = self::table_cities();

        $name = isset($data['name']) ? sanitize_text_field($data['name']) : '';
        if ($name === '') { return new WP_Error('smn_invalid_city', 'City name is required.'); }

        $county = isset($data['county']) ? sanitize_text_field($data['county']) : null;
        $state = isset($data['state']) ? sanitize_text_field($data['state']) : null;

        $ok = $wpdb->insert($table, array(
            'name' => $name,
            'county' => $county,
            'state' => $state,
            'created_at' => self::now(),
        ), array('%s','%s','%s','%s'));

        if ($ok === false) {
            return new WP_Error('smn_db_insert_failed', 'Failed to create city.', array('db_error' => $wpdb->last_error));
        }
        return (int) $wpdb->insert_id;
    }

    public static function get_cities($filters = array()) {
        global $wpdb;
        $table = self::table_cities();

        $where = array("1=1");
        $args = array();

        if (!empty($filters['county'])) { $where[] = "county = %s"; $args[] = sanitize_text_field($filters['county']); }
        if (!empty($filters['state'])) { $where[] = "state = %s"; $args[] = sanitize_text_field($filters['state']); }

        $sql = "SELECT * FROM {$table} WHERE " . implode(' AND ', $where) . " ORDER BY name ASC";
        return empty($args) ? $wpdb->get_results($sql, ARRAY_A) : $wpdb->get_results($wpdb->prepare($sql, $args), ARRAY_A);
    }

    public static function create_county($data) {
        global $wpdb;
        $table = self::table_counties();

        $name = isset($data['name']) ? sanitize_text_field($data['name']) : '';
        if ($name === '') { return new WP_Error('smn_invalid_county', 'County name is required.'); }

        $state = isset($data['state']) ? sanitize_text_field($data['state']) : null;

        $ok = $wpdb->insert($table, array(
            'name' => $name,
            'state' => $state,
            'created_at' => self::now(),
        ), array('%s','%s','%s'));

        if ($ok === false) {
            return new WP_Error('smn_db_insert_failed', 'Failed to create county.', array('db_error' => $wpdb->last_error));
        }
        return (int) $wpdb->insert_id;
    }

    public static function get_counties($filters = array()) {
        global $wpdb;
        $table = self::table_counties();

        $where = array("1=1");
        $args = array();

        if (!empty($filters['state'])) { $where[] = "state = %s"; $args[] = sanitize_text_field($filters['state']); }

        $sql = "SELECT * FROM {$table} WHERE " . implode(' AND ', $where) . " ORDER BY name ASC";
        return empty($args) ? $wpdb->get_results($sql, ARRAY_A) : $wpdb->get_results($wpdb->prepare($sql, $args), ARRAY_A);
    }
}
