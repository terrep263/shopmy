<?php
if (!defined('ABSPATH')) { exit; }

class SMN_Roles {

    public static function add_roles() {
        // Platform Admin
        add_role('platform_admin', 'Platform Admin', array(
            'read' => true,
            'manage_platform' => true,
            'manage_businesses' => true,
            'manage_vendors' => true,
            'manage_all_counties' => true,
            'manage_all_deals' => true,
            'manage_platform_settings' => true,
        ));

        // County Admin
        add_role('county_admin', 'County Admin', array(
            'read' => true,
            'manage_county_businesses' => true,
            'manage_county_vendors' => true,
            'manage_county_deals' => true,
        ));

        // Vendor
        add_role('vendor', 'Vendor', array(
            'read' => true,
            'manage_own_business' => true,
            'manage_own_deals' => true,
        ));

        // Customer
        add_role('customer', 'Customer', array(
            'read' => true,
        ));
    }

    public static function remove_roles() {
        remove_role('platform_admin');
        remove_role('county_admin');
        remove_role('vendor');
        remove_role('customer');
    }
}
