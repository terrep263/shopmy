<?php
/**
 * Plugin Name: ShopMyNeighborhood Core
 * Description: Core foundation plugin for ShopMyNeighborhood. Provides database tables, roles, permissions, admin menu, and REST API foundation.
 * Version: 1.0.0
 * Author: ATLV Solutions
 * Text Domain: shopmyneighborhood-core
 */

if (!defined('ABSPATH')) { exit; }

define('SMN_CORE_VERSION', '1.0.0');
define('SMN_CORE_DB_VERSION', '1.0.0');
define('SMN_CORE_PATH', plugin_dir_path(__FILE__));
define('SMN_CORE_URL', plugin_dir_url(__FILE__));

require_once SMN_CORE_PATH . 'includes/class-smn-activator.php';
require_once SMN_CORE_PATH . 'includes/class-smn-deactivator.php';
require_once SMN_CORE_PATH . 'includes/class-smn-core.php';

register_activation_hook(__FILE__, array('SMN_Activator', 'activate'));
register_deactivation_hook(__FILE__, array('SMN_Deactivator', 'deactivate'));

function smn_core_boot() {
    return SMN_Core::instance();
}
smn_core_boot();
