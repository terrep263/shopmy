
<?php
if (!defined('ABSPATH')) exit;

class SMN_Platform {

    public function init() {
        $this->load_modules();
        $this->register_admin_menu();
        $this->register_elementor_widgets();
    }

    private function load_modules() {
        foreach (glob(SMN_PLATFORM_PATH . 'modules/*/module.php') as $module) {
            require_once $module;
        }
    }

    private function register_admin_menu() {
        add_action('admin_menu', function() {
            add_menu_page(
                'ShopMyNeighborhood Platform',
                'SMN Platform',
                'manage_options',
                'smn-platform',
                [$this, 'dashboard'],
                'dashicons-store',
                3
            );
        });
    }

    public function dashboard() {
        echo '<div class="wrap"><h1>ShopMyNeighborhood Platform</h1>';
        echo '<p>Platform modules are active.</p></div>';
    }

    private function register_elementor_widgets() {
        add_action('elementor/widgets/register', function($widgets_manager) {
            require_once SMN_PLATFORM_PATH . 'elementor/widgets/class-smn-business-list-widget.php';
            $widgets_manager->register(new SMN_Elementor_Business_List_Widget());
        });
    }
}
