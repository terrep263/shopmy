
<?php
if (!defined('ABSPATH')) exit;

class SMN_Elementor_Business_List_Widget extends \Elementor\Widget_Base {

    public function get_name() { return 'smn_business_list'; }

    public function get_title() { return 'SMN Business List'; }

    public function get_icon() { return 'eicon-post-list'; }

    public function get_categories() { return ['general']; }

    protected function render() {
        global $wpdb;
        $table = $wpdb->prefix . 'smn_businesses';
        $businesses = $wpdb->get_results("SELECT name, city FROM $table LIMIT 10");

        echo '<ul>';
        if ($businesses) {
            foreach ($businesses as $biz) {
                echo '<li>' . esc_html($biz->name) . ' - ' . esc_html($biz->city) . '</li>';
            }
        } else {
            echo '<li>No businesses found.</li>';
        }
        echo '</ul>';
    }
}
