
<?php
/*
Plugin Name: ShopMyNeighborhood Platform
Description: Platform modules including DealGuard, Importer, Subscriptions, Vouchers, Claims, AI, Admin tools, and Elementor integration.
Version: 1.0.0
Author: ShopMyNeighborhood
*/

if (!defined('ABSPATH')) exit;

define('SMN_PLATFORM_VERSION', '1.0.0');
define('SMN_PLATFORM_PATH', plugin_dir_path(__FILE__));
define('SMN_PLATFORM_URL', plugin_dir_url(__FILE__));

require_once SMN_PLATFORM_PATH . 'includes/class-smn-platform.php';

function smn_platform_init() {
    $platform = new SMN_Platform();
    $platform->init();
}

add_action('plugins_loaded', 'smn_platform_init');
