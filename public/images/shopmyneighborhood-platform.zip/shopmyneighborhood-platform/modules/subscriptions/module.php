
<?php
if (!defined('ABSPATH')) exit;

class SMN_Module_Subscriptions {

    public function __construct() {
        add_action('init', [$this, 'init']);
    }

    public function init() {
        // subscriptions module initialization logic
    }
}

new SMN_Module_Subscriptions();
