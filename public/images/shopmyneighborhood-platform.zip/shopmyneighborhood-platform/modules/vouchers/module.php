
<?php
if (!defined('ABSPATH')) exit;

class SMN_Module_Vouchers {

    public function __construct() {
        add_action('init', [$this, 'init']);
    }

    public function init() {
        // vouchers module initialization logic
    }
}

new SMN_Module_Vouchers();
