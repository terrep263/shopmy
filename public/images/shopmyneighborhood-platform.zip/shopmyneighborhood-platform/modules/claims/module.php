
<?php
if (!defined('ABSPATH')) exit;

class SMN_Module_Claims {

    public function __construct() {
        add_action('init', [$this, 'init']);
    }

    public function init() {
        // claims module initialization logic
    }
}

new SMN_Module_Claims();
