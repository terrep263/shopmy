
<?php
if (!defined('ABSPATH')) exit;

class SMN_Module_Importer {

    public function __construct() {
        add_action('init', [$this, 'init']);
    }

    public function init() {
        // importer module initialization logic
    }
}

new SMN_Module_Importer();
