
<?php
if (!defined('ABSPATH')) exit;

class SMN_Module_Admin {

    public function __construct() {
        add_action('init', [$this, 'init']);
    }

    public function init() {
        // admin module initialization logic
    }
}

new SMN_Module_Admin();
