
<?php
if (!defined('ABSPATH')) exit;

class SMN_Module_Dealguard {

    public function __construct() {
        add_action('init', [$this, 'init']);
    }

    public function init() {
        // dealguard module initialization logic
    }
}

new SMN_Module_Dealguard();
